-- ═══════════════════════════════════════════════════════════════
--  AffiliateDeals — MySQL Schema for Hostinger
--  Domain: dux-exch.com
--
--  How to use:
--  1. Create a database in Hostinger hPanel → Databases → MySQL
--  2. Open phpMyAdmin from hPanel
--  3. Select your database
--  4. Click "SQL" tab and paste this entire file → Go
-- ═══════════════════════════════════════════════════════════════

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ── Categories ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `categories` (
  `id`          INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `name`        VARCHAR(255) NOT NULL,
  `name_ar`     TEXT,
  `slug`        VARCHAR(255) NOT NULL UNIQUE,
  `description` TEXT,
  `icon`        VARCHAR(50),
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Offers ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `offers` (
  `id`                    INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `title`                 VARCHAR(500) NOT NULL,
  `title_ar`              TEXT,
  `slug`                  VARCHAR(255) NOT NULL UNIQUE,
  `short_description`     TEXT,
  `short_description_ar`  TEXT,
  `long_description`      LONGTEXT,
  `long_description_ar`   LONGTEXT,
  `affiliate_url`         TEXT NOT NULL,
  `image_url`             TEXT NOT NULL,
  `cta_text`              VARCHAR(255) DEFAULT 'Get Offer',
  `cta_text_ar`           VARCHAR(255),
  `rating`                DOUBLE NOT NULL DEFAULT 4.5,
  `category_id`           INT DEFAULT NULL,
  `seo_title`             VARCHAR(500),
  `seo_title_ar`          TEXT,
  `seo_description`       TEXT,
  `seo_description_ar`    TEXT,
  `keywords`              TEXT,
  `faq_schema`            LONGTEXT,
  `is_active`             TINYINT(1) NOT NULL DEFAULT 1,
  `is_featured`           TINYINT(1) NOT NULL DEFAULT 0,
  `is_trending`           TINYINT(1) NOT NULL DEFAULT 0,
  `sort_order`            INT NOT NULL DEFAULT 0,
  `click_count`           INT NOT NULL DEFAULT 0,
  `created_at`            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            TIMESTAMP NULL,
  CONSTRAINT `fk_offers_category`
    FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Clicks ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `clicks` (
  `id`          INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `offer_id`    INT NOT NULL,
  `referrer`    TEXT,
  `user_agent`  TEXT,
  `ip`          VARCHAR(100),
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_clicks_offer`
    FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Admin users ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id`            INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `username`      VARCHAR(255) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role`          VARCHAR(50) NOT NULL DEFAULT 'admin',
  `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── SEO Settings ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `seo_settings` (
  `id`                        INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `site_title`                VARCHAR(500) NOT NULL DEFAULT 'AffiliateDeals',
  `site_title_ar`             TEXT,
  `site_description`          TEXT,
  `site_description_ar`       TEXT,
  `keywords`                  TEXT,
  `robots_txt`                TEXT,
  `google_analytics_id`       VARCHAR(100),
  `google_search_console_id`  VARCHAR(100),
  `og_image`                  TEXT,
  `allow_indexing`            TINYINT(1) NOT NULL DEFAULT 1,
  `updated_at`                TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ── Seed: default admin user (password: admin123) ────────────────
-- bcrypt hash of "admin123" with cost factor 10
INSERT IGNORE INTO `admin_users` (`username`, `password_hash`, `role`)
VALUES ('admin', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'superadmin');

-- ── Seed: default SEO settings ───────────────────────────────────
INSERT IGNORE INTO `seo_settings` (`id`, `site_title`, `site_description`, `allow_indexing`, `robots_txt`)
VALUES (
  1,
  'AffiliateDeals | dux-exch.com',
  'Discover the best affiliate offers, casino bonuses and sports betting deals.',
  1,
  'User-agent: *\nAllow: /\nDisallow: /admin\nSitemap: https://dux-exch.com/api/seo/sitemap.xml'
);

-- ── Seed: categories ─────────────────────────────────────────────
INSERT IGNORE INTO `categories` (`id`, `name`, `name_ar`, `slug`, `description`, `icon`) VALUES
(1, 'Sports Betting', 'الرياضة',   'sports-betting', 'Top sports betting platforms', '⚽'),
(2, 'Casino',        'كازينو',    'casino',         'Best online casino offers',    '🎰'),
(3, 'Poker',         'بوكر',      'poker',          'Poker rooms and tournaments',  '🃏'),
(4, 'Esports',       'إي-سبورتس', 'esports',        'Esports betting and gaming',   '🎮'),
(5, 'Live Casino',   'كازينو مباشر','live-casino',  'Live dealer casino games',     '🎲');

-- ── Note: seed offers via Admin Panel after setup ─────────────────
-- Visit https://dux-exch.com/admin → Offers → Add Offer
