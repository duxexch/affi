# Hostinger Deployment Guide — dux-exch.com
## AffiliateDeals — EN | AR | TR

---

## Overview

This guide deploys **AffiliateDeals** to Hostinger shared/business hosting using Node.js Manager.
The single Express server serves both the API and the React SPA static files.

**Features:**
- Trilingual: English / Arabic (RTL) / Turkish
- Full admin panel at `/admin`
- Click tracking & SEO analytics
- XML sitemap with hreflang (EN/AR/TR)
- SEO-ready: Open Graph, Twitter Card, JSON-LD, hreflang

---

## Step 0 — Prerequisites

- Hostinger **Business Shared Hosting** or higher (includes Node.js Manager)
- Domain `dux-exch.com` pointed to your Hostinger account
- A PostgreSQL database (see **Step 1** below)

---

## Step 1 — Database Options

The application uses **PostgreSQL**. Choose one:

### Option A — Free Cloud PostgreSQL on Neon.tech (Recommended for Hostinger Shared)
1. Go to [neon.tech](https://neon.tech) → Sign up free (no credit card)
2. Create a new project → Database name: `affiliatedeals`
3. Copy the **Connection string** — it looks like:
   ```
   postgresql://user:password@ep-xxx.us-east-2.aws.neon.tech/affiliatedeals?sslmode=require
   ```
4. Save it — use it as `DATABASE_URL` in Step 5

### Option B — Hostinger VPS / Cloud Hosting with PostgreSQL
If you are on a Hostinger KVM VPS:
```bash
sudo apt install postgresql postgresql-contrib
sudo -u postgres createdb affiliatedeals
```

### Option C — Hostinger MySQL (via provided SQL schema)
If you want to use Hostinger's built-in MySQL database:
1. In hPanel → **Databases** → **MySQL Databases** → create a new database
2. Open **phpMyAdmin** → select your database
3. Click **SQL** tab → paste the contents of **`mysql_schema.sql`** from this project → click Go
4. The tables and default admin user will be created

> **Note:** The MySQL option requires a code migration — contact your developer to switch the DB adapter from PostgreSQL to MySQL, or use Neon.tech (free, 2 minutes to set up).

---

## Step 2 — Build the Deployment Package

On your development machine:

```bash
# Install dependencies
pnpm install

# Build the deployment package
bash scripts/create-hostinger-package.sh
```

This creates **`hostinger-deploy.zip`** in your project root (~5-10 MB).

---

## Step 3 — Upload to Hostinger

1. Login to **hPanel** → **File Manager**
2. Navigate to your home directory (e.g. `/home/username/`)
3. Create a folder: `affiliatedeals`
4. Upload `hostinger-deploy.zip` into that folder
5. Right-click the zip → **Extract** → extract here

You should now have:
```
/home/username/affiliatedeals/
├── server.js        ← Hostinger startup file
├── dist/            ← Compiled Express server
├── public/          ← Built React SPA (EN + AR + TR)
├── package.json
└── .env.example
```

---

## Step 4 — Configure Node.js Manager in hPanel

1. hPanel → **Node.js** (or "Node.js Manager")
2. Click **Create Application**

| Field | Value |
|---|---|
| Node.js version | **20.x** or 22.x |
| Application mode | **Production** |
| Application root | `/home/username/affiliatedeals` |
| Application startup file | **server.js** |
| Application URL | `dux-exch.com` |

3. Click **Create**

---

## Step 5 — Set Environment Variables

Inside the Node.js app settings, find **Environment Variables** and add:

| Variable | Value | Notes |
|---|---|---|
| `DATABASE_URL` | `postgresql://...` | From Step 1 |
| `NODE_ENV` | `production` | Required |
| `SITE_URL` | `https://dux-exch.com` | Your domain |
| `SESSION_SECRET` | any random 64-char string | For sessions |

---

## Step 6 — Initialize the Database

Run once to create the database tables and seed sample data.

**From your local machine** (easiest):
```bash
export DATABASE_URL="postgresql://your-neon-connection-string"
pnpm --filter @workspace/db run push
```

**OR via Hostinger SSH Terminal:**
```bash
cd ~/affiliatedeals
export DATABASE_URL="postgresql://..."
node -e "
import('./dist/index.mjs').then(() => {
  console.log('Server started, tables auto-created');
  setTimeout(() => process.exit(0), 5000);
});
"
```

---

## Step 7 — Restart & Go Live

1. In hPanel → Node.js → click **Restart**
2. Visit `https://dux-exch.com` — your site should be live!
3. Visit `https://dux-exch.com/admin` → login with `admin` / `admin123`
4. **Change the admin password immediately** in Admin → Settings

---

## Verifying Everything Works

| URL | Expected Result |
|---|---|
| `https://dux-exch.com/` | Homepage (EN/AR/TR toggle) |
| `https://dux-exch.com/offers` | All Offers page |
| `https://dux-exch.com/admin` | Admin panel login |
| `https://dux-exch.com/api/healthz` | `{"status":"ok"}` |
| `https://dux-exch.com/api/seo/sitemap.xml` | XML sitemap with hreflang |
| `https://dux-exch.com/api/seo/robots.txt` | robots.txt |

---

## Language Support

The site supports 3 languages accessible via the globe icon in the navbar:

| Language | Direction | Font |
|---|---|---|
| English 🇬🇧 | LTR | Inter |
| Arabic 🇸🇦 | RTL (auto) | Cairo |
| Turkish 🇹🇷 | LTR | Inter |

Language preference is saved in the user's browser (localStorage).

---

## Admin Credentials (CHANGE BEFORE GO LIVE!)

```
Username: admin
Password: admin123
```

---

## Troubleshooting

### Site shows "Application Error"
- Check that `DATABASE_URL` is set correctly in Environment Variables
- Ensure the database tables were created (Step 6)
- Check Node.js logs in hPanel → Node.js → Logs

### 404 on page refresh (React SPA)
- The Express server handles SPA fallback automatically
- Ensure the startup file is `server.js` (not `dist/index.mjs`)

### Database connection refused
- Neon.tech: ensure connection string includes `?sslmode=require`
- Check the database user has full permissions on `affiliatedeals` database

### Arabic/Turkish text not rendering correctly
- Ensure the server is using UTF-8 encoding
- The Google Fonts (Inter + Cairo) are loaded from CDN — needs internet access

---

## SEO Features

- ✅ XML Sitemap at `/api/seo/sitemap.xml` with hreflang for EN/AR/TR
- ✅ robots.txt configurable from Admin → SEO Settings
- ✅ Open Graph tags (og:title, og:description, og:image)
- ✅ Twitter Card meta tags
- ✅ JSON-LD WebSite + Organization schema
- ✅ hreflang alternate links on every page
- ✅ Canonical URLs
- ✅ Google Analytics ID configurable from Admin → SEO Settings

---

## File Structure After Deploy

```
/home/username/affiliatedeals/
├── server.js          Startup file (configured in hPanel)
├── package.json       Minimal package manifest
├── dist/
│   ├── index.mjs      Compiled Express server (all routes bundled)
│   └── pino-worker.mjs
└── public/
    ├── index.html     React SPA entry (EN + AR + TR)
    └── assets/        CSS, JS, images (cached 1 day)
```

---

## MySQL Schema (for Option C)

The file `mysql_schema.sql` contains the complete MySQL DDL to create all tables on Hostinger's MySQL database. Run it in phpMyAdmin.

It includes:
- All 5 tables (categories, offers, clicks, admin_users, seo_settings)
- Default admin user (admin/admin123)
- Default SEO settings
- Sample categories (Sports Betting, Casino, Poker, Esports, Live Casino)
